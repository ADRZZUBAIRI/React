import './App.css'
import ToDo from './pages/ToDo'

function App() {
  

  return (
    <>
      <ToDo />
    </>
  )
}

export default App
